package com.boat.controller;
import com.boat.model.Category;
import com.boat.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;
import org.springframework.http.HttpStatus;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
@RestController
@RequestMapping("/Category")
@CrossOrigin(origins = "*", methods= {RequestMethod.GET,RequestMethod.POST,RequestMethod.PUT,RequestMethod.DELETE})
public class CategoryController {
    /**
     * Inyector de dependencias
     */
    @Autowired
    private CategoryService categoryService;
    /**
     * @return Método que llama o solicita el servicio que lista los elementos de la base de datos
     */
    @GetMapping("/all")
    public List<Category> getAll(){
        return categoryService.getAll();
    }
    /**
     * @param id
     * @return Método que llama o solicita el servicio que lista un elemento especeifico de la base de datos
     */
    @GetMapping("/{id}")
    public Optional<Category> getCategory(@PathVariable int id){
        return categoryService.getCategory(id);
    }
    /**
     * @param category
     * @return Método que llama o solicita el servicio que crea un nuevo registro en la base de datos
     */
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.CREATED)
    public Category save(@RequestBody Category category) {
        return categoryService.save(category);
    }
    /**
     * @param id
     * @return Método que llama o solicita el servicio que borra un elemento de la base de datos
     */
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public boolean deleteCategory(@PathVariable int id){
        return categoryService.deleteCategory(id);
    }
    /**
     * @param category
     * @return Método que llama o solicita el servicio que edita un elemento de la base de datos
     */
    @PutMapping("/update")
    @ResponseStatus(HttpStatus.CREATED)
    public Category updateCategory(@RequestBody Category category){
        return categoryService.updateCategory(category);
    }
}