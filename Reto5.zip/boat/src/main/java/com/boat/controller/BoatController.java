package com.boat.controller;
import com.boat.model.Boat;
import com.boat.service.BoatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;
import org.springframework.http.HttpStatus;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
@RestController
@RequestMapping("/Boat")
@CrossOrigin(origins = "*", methods= {RequestMethod.GET,RequestMethod.POST,RequestMethod.PUT,RequestMethod.DELETE})
public class BoatController {
    /**
     * Inyector de dependencias
     */
    @Autowired
    private BoatService boatService;
    /**
     * @return Método que llama o solicita el servicio que lista los elementos de la base de datos
     */
    @GetMapping("/all")
    public List<Boat> getAll(){
        return boatService.getAll();
    }
    /**
     * @param id
     * @return Método que llama o solicita el servicio que lista un elemento especeifico de la base de datos
     */
    @GetMapping("/{id}")
    public Optional<Boat> getBoat(@PathVariable int id){
        return boatService.getBoat(id);
    }
    /**
     * @param boat
     * @return Método que llama o solicita el servicio que crea un nuevo registro en la base de datos
     */
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.CREATED)
    public Boat save(@RequestBody Boat boat) {
        return boatService.save(boat);
    }
    /**
     * @param id
     * @return Método que llama o solicita el servicio que borra un elemento de la base de datos
     */
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public boolean deleteBoat(@PathVariable int id){
        return boatService.deleteBoat(id);
    }
    /**
     * @param boat
     * @return Método que llama o solicita el servicio que edita un elemento de la base de datos
     */
    @PutMapping("/update")
    @ResponseStatus(HttpStatus.CREATED)
    public Boat updateBoat(@RequestBody Boat boat){
        return boatService.updateBoat(boat);
    }
}