package com.boat.model;;
import javax.persistence.*;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
@Entity
@Table(name = "admin")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Admin implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    /**
     * Identificador del usuario administrador
     */
    private Integer idAdmin;
    /**
     * Correo del usuario administrador
     */
    private String email;
    /**
     * Contraseña del usuario administrador
     */
    private String password;
    /**
     * Nombre del usuario administrador
     */
    private String name;
}
