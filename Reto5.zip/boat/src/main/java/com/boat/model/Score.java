package com.boat.model;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.persistence.*;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
@Entity
@Table(name = "score")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Score implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    /**
     * Identificador de la puntuacion
     */
    private Integer idScore;
    /**
     * Mensaje de la puntuacion
     */
    private String messageText;
    /**
     * Calificacion
     */
    private Integer stars;
    /**
     * Modelo relacional de una a uno entre Puntacion y Reserva
     */
    @OneToOne
    @JsonIgnoreProperties("score")
    private Reservation reservation;
}