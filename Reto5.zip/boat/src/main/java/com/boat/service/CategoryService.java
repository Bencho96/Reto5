package com.boat.service;
import com.boat.model.Category;
import com.boat.repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
@Service
public class CategoryService {
    /**
     * Inyector de dependencias
     */
    @Autowired
    private CategoryRepository categoryRepository;
    /**
     * @return Servicio que lista los elementos de la base de datos
     */
    public List<Category> getAll() {
        return categoryRepository.getAll();
    }
    /**
     * @param id
     * @return Servicio que lista un elemento especeifico de la base de datos
     */
    public Optional<Category> getCategory(int id) {
        return categoryRepository.getCategory(id);
    }
    /**
     * @param category
     * @return Servicio que crea un nuevo registro en la base de datos
     */
    public Category save(Category category) {
        if (category.getId() == null) {
            return categoryRepository.save(category);
        } else {
            Optional<Category> category1 = categoryRepository.getCategory(category.getId());
            if (category1.isEmpty()) {
                return categoryRepository.save(category);
            } else {
                return category;
            }
        }
    }
    /**
     * @param id
     * @return Servicio que borra un elemento de la base de datos
     */
    public boolean deleteCategory(int id){
        Optional<Category> miCategoria = categoryRepository.getCategory(id);
        if (miCategoria.isEmpty()){
            return false;
        }else{
            categoryRepository.delete(miCategoria.get());
            return true;
        }
    }
    /**
     * @param category
     * @return Servicio que edita un elemento de la base de datos
     */
    public Category updateCategory(Category category){
        if (category.getId()!=null){
            Optional<Category> categoria = categoryRepository.getCategory(category.getId());
            if (!categoria.isEmpty()){
               if (category.getName()!=null){
                   categoria.get().setName(category.getName());
               }
               if (category.getDescription()!=null){
                   categoria.get().setDescription(category.getDescription());
               }
               return categoryRepository.save(categoria.get());
            }else{
               return category;
            }
        }
        return category;     
    }
}