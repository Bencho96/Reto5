package com.boat.repository.crud;
import com.boat.model.Client;
import org.springframework.data.repository.CrudRepository;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
public interface ClientCrudRepository extends CrudRepository<Client,Integer> {}