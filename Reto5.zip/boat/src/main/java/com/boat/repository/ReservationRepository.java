package com.boat.repository;
import com.boat.model.Client;
import com.boat.model.Reservation;
import com.boat.model.custom.CountClient;
import com.boat.repository.crud.ReservationCrudRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
@Repository
public class ReservationRepository {
    /**
     * Inyector de dependencias
     */
    @Autowired
    private ReservationCrudRepository reservationCrudRepository;
    /**
     * @return Contiene la interfaz que extiende de JPA para que el metodo que lista todos los elementos se conecte a la base de datos
     */
    public List<Reservation> getAll(){
        return (List<Reservation>) reservationCrudRepository.findAll();
    }
    /**
     * @param id Contiene la interfaz que extiende de JPA para que el metodo que lista un solo elemento se conecte a la base de datos
     * @return 
     */
    public Optional<Reservation> getReservation(int id){
        return reservationCrudRepository.findById(id);
    }
    /**
     * @param reservation Contiene la interfaz que extiende de JPA para que el metodo que crea un nuevo registro se conecte a la base de datos
     * @return 
     */
    public Reservation save(Reservation reservation){
        return reservationCrudRepository.save(reservation);
    }
    /**
     * @param reservation Contiene la interfaz que extiende de JPA para que el metodo que borra un elemento se conecte a la base de datos
     */
    public void delete(Reservation reservation){
        reservationCrudRepository.delete(reservation);
    }
    /**
     * @param a
     * @param b
     * @return Contiene la interfaz que extiende de JPA para que el metodo que genera un reporte
     * de reservas se conecte a la base de datos
     */
    public List<Reservation> getReservationPeriod(Date a, Date b){
        return reservationCrudRepository.findAllByStartDateAfterAndStartDateBefore(a,b);
    }
    /**
     * @param status
     * @return Contiene la interfaz que extiende de JPA para que el metodo que genera un informe
     * de reservascompletadas vs canceladas se conecte a la base de datos
     */
     public List<Reservation> getReservationsByStatus(String status){
        return reservationCrudRepository.findAllByStatus(status);
    }
    /**
     * @return Contiene la interfaz que extiende de JPA para que el metodo que genera un informe
     * de los clientes con más reservas completas se conecte a la base de datos
     */
    public  List<CountClient> getTopClients(){
        List<CountClient>res=new ArrayList<>();
        List<Object[]>report=reservationCrudRepository.countTotalReservationsByClient();
        for(int i=0;i<report.size();i++){
            res.add(new CountClient((Long)report.get(i)[1],(Client) report.get(i)[0]));
        }
        return res;
    } 
}