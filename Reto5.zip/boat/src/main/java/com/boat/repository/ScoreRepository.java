package com.boat.repository;
import com.boat.model.Score;
import com.boat.repository.crud.ScoreCrudRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
@Repository
public class ScoreRepository {
    /**
     * Inyector de dependencias
     */
    @Autowired
    private ScoreCrudRepository scoreCrudRepository;
    /**
     * @return Contiene la interfaz que extiende de JPA para que el metodo que lista todos los elementos se conecte a la base de datos
     */
    public List<Score> getAll(){
        return (List<Score>) scoreCrudRepository.findAll();
    }
    /**
     * @param id Contiene la interfaz que extiende de JPA para que el metodo que lista un solo elemento se conecte a la base de datos
     * @return 
     */
    public Optional<Score> getScore(int id){
        return scoreCrudRepository.findById(id);
    }
    /**
     * @param score Contiene la interfaz que extiende de JPA para que el metodo que crea un nuevo registro se conecte a la base de datos
     * @return 
     */
    public Score save(Score score){
        return scoreCrudRepository.save(score);
    }
    /**
     * @param score Contiene la interfaz que extiende de JPA para que el metodo que borra un elemento se conecte a la base de datos
     */
    public void delete(Score score){
        scoreCrudRepository.delete(score);
    }   
}