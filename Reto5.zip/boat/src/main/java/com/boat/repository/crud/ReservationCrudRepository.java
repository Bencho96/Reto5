package com.boat.repository.crud;
import com.boat.model.Reservation;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import java.util.Date;
import java.util.List;
/**
 * Reto 5 - Backend Boat informes
 * @author Ruben Hernan Ramirez Castillo - G13
 */
public interface ReservationCrudRepository extends CrudRepository<Reservation,Integer> {
   /**
    * @param dateOne
    * @param dateTwo
    * @return Metodo para generar el reporte de conteo de Reservas
    */
   public List<Reservation> findAllByStartDateAfterAndStartDateBefore(Date dateOne,Date dateTwo );
   /**
    * @param status
    * @return Metodo para generar el reporte de conteo de Reservascompletadas vs canceladas
    */   
   public List<Reservation> findAllByStatus(String status);
    /**
    * @return Metodo para generar el reporte de top mejores clientes
    * SELECT count(*),`client_id` FROM `reservation` group by `client_id` order by count(*) desc;
    */
    @Query("SELECT c.client, COUNT(c.client) from Reservation AS c group by c.client order by COUNT(c.client) DESC")
    public List<Object[]> countTotalReservationsByClient();
}
